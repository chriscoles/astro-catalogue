package org.example.mssqlhibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MssqlHibernateApplication {

    public static void main(String[] args) {
        SpringApplication.run(MssqlHibernateApplication.class, args);
    }

}
