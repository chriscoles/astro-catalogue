package org.example.mssqlhibernate.dao;

import org.example.mssqlhibernate.entity.Messier;

import java.util.List;

public interface MessierDAO {

    public List<Messier> getMessier();
}
