package org.example.mssqlhibernate.service;

import org.example.mssqlhibernate.entity.Messier;

import java.util.List;

public interface MessierService {
    public List<Messier> getMessier();

}
