package org.example.mssqlhibernate.service;

import org.example.mssqlhibernate.dao.MessierDAO;
import org.example.mssqlhibernate.entity.Messier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MessierServiceImpl implements MessierService{

    @Autowired
    private MessierDAO messierDAO;

    @Override
    @Transactional
    public List<Messier> getMessier() {
        return messierDAO.getMessier();
    }
}
